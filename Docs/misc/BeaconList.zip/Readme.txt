This archive contains an updated version of the Beacon.lst file that includes
the new KH6RS beacon. Please place this file in the directory where Faros is
installed. The default installation directory is

C:\Program Files (x86)\Afreet\Faros\

73 Alex VE3NEA